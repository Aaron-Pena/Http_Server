
package http_server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rnavarro
 */
public class HTTPService implements Runnable {

    private static final Logger LOG = Logger.getLogger(HTTPService.class.getName());
    
    private Socket clientSocket;

    public HTTPService(Socket c) {
        clientSocket = c;
    }

    @Override
    public void run() {
        BufferedReader in
                = null;
        try {
            PrintWriter out
                    = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(
                    new InputStreamReader(clientSocket.getInputStream()));
            String inputLine;
            
            // leer la solicitud del cliente
            while ((inputLine = in.readLine()) != null) {   
                if(inputLine.startsWith("GET")){
                    String[] s= inputLine.split("ejercicio.html");
                    LOG.info(inputLine);
                }
                System.out.println(inputLine);
                
                //Si recibimos linea en blanco, es fin del la solicitud
                if( inputLine.isEmpty() ) {
                    break;
                }
            }
            File f= new File("ejercicio.html");
            
            out.println("HTTP/1.1 200 OK");
            out.println("Content-Type: text/html; charset=utf-8" );
            out.println("Content-Length: "+ f.length());
            out.println();
            
          //FileReader  file = new FileReader("index.html");
               FileReader  file = new FileReader("ejercicio.html");         
            int data;
            System.out.println("sending");
                    
            while( (data = file.read()) != -1 ) {
                out.write(data);
                out.flush();     
                //System.out.println(".");
            }
            
            System.out.println("done");
            file.close();
            clientSocket.close();
        } catch (IOException ex) {
            System.out.println("Error en la conexion");
        } finally {
            try {
                in.close();
            } catch (IOException ex) {
                Logger.getLogger(HTTPService.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
